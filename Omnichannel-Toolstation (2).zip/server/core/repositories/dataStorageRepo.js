class Repository {

    async setDataStore(accessToken) {
        try {
            return await $db.set("eposAccessToken", { "eposAccessToken": accessToken });
        } catch (err) {
            return err
        }
    };

};

exports.Repository = Repository;