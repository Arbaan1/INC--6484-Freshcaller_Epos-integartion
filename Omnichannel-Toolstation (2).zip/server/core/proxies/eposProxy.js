const btoa = require("btoa");

class EposProxy {

    async eposAccessToken(iparams) {
        try {
            const url = `https://${iparams.eposDomain}/oauth2/v1/accesstoken?grant_type=client_credentials`;
            const headers = {
                Authorization: "Basic " + btoa(`${iparams.eposClientKey}:${iparams.eposClientSecret}`)
            };
            return await $request.post(url, { headers });
        } catch (err) {
            return err;
        }
    };

};

exports.EposProxy = EposProxy;