const DAYJS = require("dayjs");

class ScheduleEventService {

    async createSchedule(payload) {

        const scheduleArgs = {
            name: `renewelAccessTokenScheduler`,
            data: {
                scheduleType: "ACCESS_TOKEN",
                payload: payload
            },
            datetime: DAYJS().add(6, "minutes").toISOString(),
            
            // datetime: DAYJS().toISOString(),
        };
        console.log(scheduleArgs,"scheduleArgs")
        console.log("datetime", scheduleArgs.datetime, new Date(scheduleArgs.datetime).getTime());

        $schedule.create({
            name: scheduleArgs.name,
            data: scheduleArgs.data,
            schedule_at: scheduleArgs.datetime,
            repeat: {
                time_unit: "minutes",
                frequency: 10
            }
        }).then(
            function (data) {
                console.log("schedule successfully created----------->", data);
            },
            function (err) {
                console.log("errrrrrr", err);
                return err;
            }
        );

    };

};

exports.ScheduleEventService = ScheduleEventService;