const { EposProxy } = require("../proxies/eposProxy");
const eposProxy = new EposProxy();

class EposServices {

    async getEposAccessToken(payload) {
        try {
            const iparams = payload.iparams;
            return await eposProxy.eposAccessToken(iparams);
        } catch (err) {
            return err;
        }
    };

};

exports.EposServices = EposServices;  