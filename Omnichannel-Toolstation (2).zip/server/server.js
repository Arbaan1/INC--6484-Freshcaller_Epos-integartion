const { EposServices } = require("./core/services/eposServices");
const { ScheduleEventService } = require("./core/services/scheduleServices");
const { Repository } = require("./core/repositories/dataStorageRepo");
const eposServices = new EposServices();
const scheduleServices = new ScheduleEventService();
const repository = new Repository();

exports = {

    onAppInstallCallback: async function (payload) {
        try {
            console.log("onAppInstallCallback", new Date().getTime());
            await scheduleServices.createSchedule(payload);
            renderData();
        } catch (err) {
            return err;
        }
    },

    onScheduledEventHandler: async function (payload) {
        try {
            console.log("onScheduledEventHandler", Date.now());
            const tokenResponse = await eposServices.getEposAccessToken(payload);
            const accessToken = JSON.parse(tokenResponse.response).access_token;
            console.log("accessToken", accessToken);
            return await repository.setDataStore(accessToken);
        } catch (err) {
            return err;
        }
    },

};