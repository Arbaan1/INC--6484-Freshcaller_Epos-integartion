var client;
var iparams = {}
var freshdeskcontactId = "";
var eposAccessToken = "";
var contactDetails = []
var contactId = '';
var eposContactId = "";
var orderDetails = []
init();

async function init() {
    client = await app.initialized();
    client.events.on('app.activated');
    await indexOnloadDatas();
};
const indexOnloadDatas = async () => {
    $("#indexCover-spin").show();
    await loadIparams();
    await incoming();
    await appendCardContactsList();
};
const capitalize = (subject) => {
    return subject.charAt(0).toUpperCase() + subject.slice(1);
};
const loadIparams = async () => {
    try {
        const data = await client.iparams.get()
            .catch((error) => {
                return error;
            });
        iparams = data;
        return iparams;
    } catch (err) {
        console.log("loadIparams", err);
        return err;
    }
};
const incoming = async()=>{

    try{
      const incomingcalldetails= await client.data.get("currentCall");
      callermail=incomingcalldetails.caller.to;
      console.log(callermail,"Number for incoming call");
      return searchNumber(callermail);
}
catch(err){
         return err
    }
}
const searchNumber=async(number)=>{
    try{
    const countryCode=number.slice(1,-10);
    console.log(countryCode,"countrycode");
    const phoneNumber= number.slice(-10);
   const url=`https://${iparams.fdDomain}/api/v2/contacts?phone=%2B${countryCode}${phoneNumber}`;
   const headers={
       Authorization: "Basic " + btoa(iparams.fdApikey),
   }
   console.log(url,"url for search number");
   const contact=await client.request.get(url,{ headers });
   const dataresponse=JSON.parse(contact.response);
   console.log(dataresponse,"Responseoffreshdeskcontact");
   const postalcode=dataresponse[0].custom_fields.postal_code;
   freshdeskcontactId=dataresponse[0].id;
   console.log(freshdeskcontactId,"freshdeskcontactId in searchnumber");
   console.log(postalcode,"postalcode")
   return toolstationpostcodeAPI(postalcode,phoneNumber);
}
catch(err){
    console.log(err,"Error in search_number");
   return err
}
}
const getDbAccessToken = async () => {
    
    try {
        accessToken = await client.db.get("eposAccessToken");
        eposAccessToken = accessToken.eposAccessToken;
        return eposAccessToken;
    } catch (err) {
        // console.log("getDbAccessToken", err);
        return err;
    }
};

const toolstationpostcodeAPI=async(postalcode,phoneNumber)=>{
     await getDbAccessToken();
     console.log(phoneNumber,"phoneNumber 2");
    try{
        const firstcode=postalcode.slice(0,3);
        console.log(firstcode,"firstcode");
        const lastcode=postalcode.slice(-3);
        console.log(lastcode,"lastcode");
        // const url =`https://${iparams.eposDomain}/internal/v1/customers?postcode=${firstcode}%20${lastcode}&telephone=00${countryCode}${phoneNumber}`
        const url =`https://${iparams.eposDomain}/internal/v1/customers?postcode=${firstcode}%20${lastcode}&telephone=0${phoneNumber}`
        const headers = {
            'Accept': 'application/json',
            Authorization: `Bearer ${eposAccessToken}`
        }
        console.log(url,"Epos url for postcode&&phonenumber");
     const Response = await client.request.get(url, { headers });
     const ToolstationResponse= JSON.parse(Response.response).data;
     console.log("ToolstationResponse",ToolstationResponse);
     contactDetails =ToolstationResponse;

    }
    catch(err){
        console.log("Error in  toolstationpostcodeAPI",err);
        return err
        

    }
}

const appendCardContactsList = async () => {
    try {

        const cardContactsList = $(".cardContactsList");

        let indexContactlistHtml = ``;

        indexContactlistHtml += `<p class="app-heading"><b>ToolStation Customers List</b></p>`;
        indexContactlistHtml += `<hr>`;


        if (contactDetails) {

            if (contactDetails.length == 0) {
                indexContactlistHtml += `<div id="indexNoContact"><h2 id="indexContactNoData"><span>No Data Found</span></h2></div>`;
                cardContactsList.html(indexContactlistHtml);
                $("#indexCover-spin").hide();
                return;
            }

            indexContactlistHtml += `<table class="cardContactsListTable">`;
            indexContactlistHtml += `<tbody>`;

            for (let i = 0; i < contactDetails.length; i++) {

                let contactData = contactDetails[i];

                indexContactlistHtml += `<tr>`;
                indexContactlistHtml += `<td class="cardIndexContactList"><span><a class="link" id=${contactData.id} onclick="getSelectedContactDetails(this.id)">${contactData.full_name} - ${contactData.id}</a></span></td>`;
                indexContactlistHtml += `</tr>`;

            }

            indexContactlistHtml += `</tbody>`;
            indexContactlistHtml += `</table>`;

        } else {
            indexContactlistHtml += `<div id="indexNoContact"><h2 id="indexContactNoData"><span>No Data Found</span></h2></div>`;
            cardContactsList.html(indexContactlistHtml);
            $("#indexCover-spin").hide();
            return;
        }

        cardContactsList.html(indexContactlistHtml);
        $("#indexCover-spin").hide();

        resizeSideBar("cardContactsList");

    } catch (err) {
        $("#indexCover-spin").hide();
        console.log("appendCardContactsList->Error->", err);
        return err;
    }

};
const getSelectedContactDetails = async (id) => {
    try {

        $("#indexCover-spin").show();
        await getDbAccessToken();
        const url = `https://${iparams.eposDomain}/internal/v1/customers/${id}`;
        const headers = {
            'Accept': 'application/json',
            Authorization: `Bearer ${eposAccessToken}`
        }
        const contactResponse = await client.request.get(url, { headers });
        const contactData = JSON.parse(contactResponse.response).data;
        console.log(contactData,"cardbuttonlink");
        await appendIndexContactDetails(contactData);

    } catch (err) {

        $("#indexCover-spin").hide();
        console.log("getSelectedContactDetails->Error->", err);
        return err;

    }

};
const getDbData = async () => {
    try {

        return await client.db.get("contactConfiguration");

    } catch (err) {
        console.log("getDbData->Error->", err);
        return err;
    }

};
var selectedFields = [];
const appendIndexContactDetails = async (contactData) => {
    try {

        let indexContactDetails = $(".indexContactDetails");

        let indexContactHtml = ``;

        const dbData = await getDbData();

        if (dbData.status == 404) {
            indexContactHtml += `<div id="indexNoContact"><h2 id="indexContactNoData"><span>No Configuration Found</span></h2></div>`;
            indexContactDetails.html(indexContactHtml);

            $(".indexContactDetails").show();
            $(".cardContactsList").hide();
            $("#indexCover-spin").hide();
            return;
        }

        Object.entries(dbData).forEach(([key, value]) => {

            if (value.isIndex) {
                selectedFields.push(key);
            }

        });
        indexContactHtml += `<fw-button size="icon" id="backBtn">`
        indexContactHtml += `<fw-icon name="arrow-left" color="white"></fw-icon>`
        indexContactHtml += `</fw-button>`;

        indexContactHtml += `<p class="app-heading"><b>ToolStation Customer Details</b></p>`;
        indexContactHtml += `<hr>`;

        if (contactData.length == 0) {
            indexContactHtml += `<div id="indexNoContact"><h2 id="indexContactNoData"><span>No Data Found</span></h2></div>`;
            indexContactDetails.html(indexContactHtml);
            $("#indexCover-spin").hide();
            return;
        }

        indexContactHtml += ` <table class="indexContactDetailsTable">`;
        indexContactHtml += ` <tbody>`;

        Object.entries(contactData).forEach(([key, value]) => {
            if (selectedFields.includes(key)) {

                let replacedKey = key.replaceAll('_', ' ');
                let keyLabel = replacedKey.split(' ').map(capitalize).join(' ');

                if (key == "id") {

                    contactId = value;

                    indexContactHtml += `<tr>`;
                    indexContactHtml += `<td class="indexContactTd">${keyLabel}<span><fw-button class="clipboard-btn" size="icon" color="secondary" onclick="copyUID()">
                                         <fw-icon name="copy" size="14" color="#2c5cc5"></fw-icon>
                                         </fw-button></span></td>`;
                    indexContactHtml += `<td>:</td>`;
                    indexContactHtml += `<td id="UID"><span><a class="link" id="${value}" onclick="contactLinkRedirect(this.id)">${value}</a></span></td>`;
                    indexContactHtml += `</tr>`;

                }
                else if (key == "primary_address") {
                    indexContactHtml += `<tr>`;
                    indexContactHtml += `<td class="contactHeadingTd">${keyLabel} :</td>`;
                    indexContactHtml += `</tr>`;
                    Object.entries(contactData.primary_address).forEach(([addressKey, addressValue]) => {

                        replacedKey = addressKey.replaceAll('_', ' ');
                        keyLabel = replacedKey.split(' ').map(capitalize).join(' ');

                        indexContactHtml += `<tr>`;
                        indexContactHtml += `<td class="contactTd">${keyLabel}</td>`;
                        indexContactHtml += `<td>:</td>`;
                        indexContactHtml += `<td>${addressValue}</td>`;
                        indexContactHtml += `</tr>`;
                    });
                }

                else {
                    indexContactHtml += `<tr>`;
                    indexContactHtml += `<td class="indexContactTd">${keyLabel}</td>`;
                    indexContactHtml += `<td>:</td>`;
                    indexContactHtml += `<td class="indexContactValueTd">${value}</td>`;
                    indexContactHtml += `</tr>`;
                }
            }
        });

        indexContactHtml += `</tbody>`;
        indexContactHtml += `</table>`;
        indexContactHtml += `<br />`;
        indexContactHtml += ` <fw-button class="loadMore" color="primary" onclick="contactOrdersCard()">Load More</fw-button>`;

        indexContactDetails.html(indexContactHtml);

        $(".indexContactDetails").show();
        $(".cardContactsList").hide();
        $("#indexCover-spin").hide();

        resizeSideBar("indexContactDetails");
        getEposOrderDetails(contactId);

    } catch (err) {

        $("#indexCover-spin").hide();
        console.log("appendIndexContactDetails", err);
        return err;

    }

};

const contactOrdersCard=()=>{
    $('.indexContactDetails').hide();
    $('.cardContactsList').hide();
    $('.contactOrderCards').show();
    $('.modalContactDetails').hide();
    try{
        let indexContactDetails = $(".contactOrderCards");

        let indexContactHtmlCard = ``;

        indexContactHtmlCard += `<fw-button size="icon" id="backBtncontact">`
        indexContactHtmlCard += `<fw-icon name="arrow-left" color="white"></fw-icon>`
        indexContactHtmlCard += `</fw-button>`;

        indexContactHtmlCard += `<p class="app-heading"><b>ToolStation Customers&&Orders</b></p>`;
        indexContactHtmlCard += `<hr>`;

        indexContactHtmlCard += ` <table class="indexContactDetailsTable">`;
        indexContactHtmlCard += ` <tbody>`;

        indexContactHtmlCard += `<tr>`;
        indexContactHtmlCard  += `<td class="cardIndexContactList"><span><a class="link"  onclick="appendEposContactDetails()">Contact Details</a></span></td><br>`;
        indexContactHtmlCard += `<td class="cardIndexContactList"><span><a class="link"  onclick="appendEposOrderDetails()">Order Details</a></span></td>`;
        indexContactHtmlCard += `</tr>`;
    
        

        indexContactHtmlCard += `</tbody>`;
        indexContactHtmlCard += `</table>`;

        $(indexContactDetails).html(indexContactHtmlCard);

    }
    catch(err){
        console.log("error", err)
        return err;

    }
}

// customer details
var selectedContact=[];
const appendEposContactDetails = async () => {
    $('.contactOrderCards').hide();
    $('.cardContactsList').hide();
    $('.indexContactDetails').hide();
    $('.modalContactDetails').show();
    try {

        const dbData = await getDbData();
        Object.entries(dbData).forEach(([key, value]) => {
            if (value.isModal) {
                selectedContact.push(key);
            }

        });

        let modalContactDetails = $(".modalContactDetails");
        let contactHtml = '';
        contactHtml += `<fw-button size="icon" id="backBtncontactdetails">`
        contactHtml += `<fw-icon name="arrow-left" color="white"></fw-icon>`
        contactHtml += `</fw-button>`;

        contactHtml += `<p class="app-heading"><b>ToolStation Customers Details</b></p>`;
        contactHtml += `<hr>`;

        if (contactDetails.length == 0) {
            contactHtml += `<div id="noContact"><h2 id="contactNoData"><span>No Data Found</span></h2></div>`;
            modalContactDetails.html(contactHtml);
            return;
        }

        contactHtml += ` <table class="modalContactDetailsTable">`;
        contactHtml += ` <tbody>`;

        Object.entries(contactDetails[0]).forEach(([key, value]) => {
            if (selectedContact.includes(key)) {

                let replacedKey = key.replaceAll('_', ' ');
                let keyLabel = replacedKey.split(' ').map(capitalize).join(' ');

                if (key == "id") {
                    eposContactId = value;
                    contactHtml += `<tr>`;
                    contactHtml += `<td class="indexContactTd">${keyLabel}<span></span></td>`;
                    contactHtml += `<td>:</td>`;
                    contactHtml += `<td id="UID"><span><a class="link" id="${value}" onclick="contactLinkRedirect(this.id)">${value}</a></span></td>`;                   
                    contactHtml += `</tr>`;
                }else if (key == "primary_address") {
                    contactHtml += `<tr>`;
                    contactHtml += `<td class="contactHeadingTd">${keyLabel} :</td>`;
                    contactHtml += `</tr>`;
                    Object.entries(contactDetails.primary_address).forEach(([addressKey, addressValue]) => {

                        replacedKey = addressKey.replaceAll('_', ' ');
                        keyLabel = replacedKey.split(' ').map(capitalize).join(' ');

                        contactHtml += `<tr>`;
                        contactHtml += `<td class="contactTd">${keyLabel}</td>`;
                        contactHtml += `<td>:</td>`;
                        contactHtml += `<td>${addressValue}</td>`;
                        contactHtml += `</tr>`;
                    });

                } else {
                    contactHtml += `<tr>`;
                    contactHtml += `<td class="contactTd">${keyLabel}</td>`;
                    contactHtml += `<td>:</td>`;
                    contactHtml += `<td>${value}</td>`;
                    contactHtml += `</tr>`;
                }
            }

        });
        contactHtml += `</tbody>`;
        contactHtml += `</table>`;
        modalContactDetails.html(contactHtml);
        $(".uploadContact").show();
        $("#cover-spin").hide();
        return eposContactId;
    } catch (err) {
        console.log("appendEposContactDetails->Error->", err);
        return err;
    }
};
// customer details end

// order details start

const getEposOrderFieldsFromDb = async () => {
    try {

        const dbData = await client.db.get("orderConfiguration");
        return Object.keys(dbData);

    } catch (err) {

        console.log("getEposOrderFieldsFromDb->Error->", err);
        return err;

    }

};
const getEposOrderDetails = async (contactId) => {
    console.log(contactId,"eposContactId for orders");
    try {
        await getDbAccessToken();
        const url = `https://${iparams.eposDomain}/internal/v1/customers/${contactId}/orders`;
        const headers = {
            'Accept': 'application/json',
            Authorization: `Bearer ${eposAccessToken}`
        }
        console.log("url",url)
        const orderResponse = await client.request.get(url, { headers });
        const orders = JSON.parse(orderResponse.response).data;
        // console.log(orders,"orders response");
        orderDetails = orders;

    } catch (err) {
        $("#cover-spin").hide();
        return err;
    }
};
const appendEposOrderDetails = async () => {
    // console.log(orderDetails,"eposContactId for orders");
    $('.contactOrderCards').hide();
    $('.cardContactsList').hide();
    $('.indexContactDetails').hide();
    $('.modalContactDetails').hide();
    $('.orderTabs').show();
    try {

        const dbOrderFields = await getEposOrderFieldsFromDb();
        let orderTabs = $(".orderTabs");
        let count = -1;
        let orderHtml = '';
        orderHtml += `<fw-button size="icon" id="backBtnorders">`
        orderHtml += `<fw-icon name="arrow-left" color="white"></fw-icon>`
        orderHtml += `</fw-button>`;
        orderHtml += `<p class="app-heading"><b>ToolStation Orders Details</b></p>`;
        orderHtml += `<hr>`;

        if (orderDetails.length == 0) {
            orderHtml += `<div id="noOrder"><h2 id="orderNoData"><span>No Data Found</span></h2></div>`;
            orderTabs.html(orderHtml);
            return;
        }

        if (dbOrderFields.status == 404) {
            orderHtml += `<div id="noOrder"><h2 id="orderNoData"><span>No Order Fields Configuration Found</span></h2></div>`;
            orderTabs.html(orderHtml);
            return;
        }

        orderHtml += ` <fw-tabs id="tabs">`
        for (let i = 0; i < 3 && orderDetails.length; i++) {
            count = count + 1;
            orderHtml += ` <fw-tab tab-header="Order ${i + 1}">`
            orderHtml += ` <table class="modalOrderDetails">`
            orderHtml += ` <tbody>`;

            Object.entries(orderDetails[count]).forEach(([key, value]) => {
                if (key) {

                    if (dbOrderFields.includes(key)) {

                        let replacedKey = typeof key == "string" ? key.replaceAll('_', ' ') : key;
                        let keyLabel = replacedKey.split(' ').map(capitalize).join(' ');

                        if (key == "id") {

                            orderId = value;

                            orderHtml += `<tr>`;
                            orderHtml += `<td class="orderTd">${keyLabel}</td>`;
                            orderHtml += `<td>:</td>`;
                            orderHtml += `<td><span><a class="link" id="${value}" onclick="trackingLinkRedirect(this.id)">${value}</a></span></td>`;
                            orderHtml += `</tr>`;
                        } else {
                            orderHtml += `<tr>`;
                            orderHtml += `<td class="orderTd">${keyLabel}</td>`;
                            orderHtml += `<td>:</td>`;
                            orderHtml += `<td>${value}</td>`;
                            orderHtml += `</tr>`;
                        }
                    }
                }
            });
            orderHtml += `</tbody>`;
            orderHtml += `</table>`
            orderHtml += `</fw-tab>`
        }
        orderHtml += `</fw-tabs>`
        orderTabs.html(orderHtml);
        $("#cover-spin").hide();
    } catch (err) {
        console.log("orderdetails",err);
        return err;
    }
};

var trackingLink = "";

const trackingLinkRedirect = async (orderId) => {
    // console.log(orderId,"tracking order Id")
    try {
        $("#cover-spin").show();
        await getEposOrderTrackingDetails(orderId);
        if (trackingLink == "" || trackingLink == []) {
            notify("Tracking Link Not Available", "error");
            $("#cover-spin").hide();
            return;
        }
        window.open(`${trackingLink}`, '_blank');
        $("#cover-spin").hide();
    } catch (err) {
        console.log("tracking error", err);
        return err;
    }
};

const getEposOrderTrackingDetails = async (orderId) => {
    try {

        console.log("orderId", orderId);
        const url = `https://${iparams.eposDomain}/internal/v1/customers/order-tracking/${orderId}`;
        const headers = {
            'Accept': 'application/json',
            Authorization: `Bearer ${eposAccessToken}`
        }
        console.log(url,"url for tracking order details");
        const trackingResponse = await client.request.get(url, { headers });
        // console.log("trackingResponse", JSON.parse(trackingResponse.response).data.tracking[0].tracking_links[0]);
        trackingLink = JSON.parse(trackingResponse.response).data.tracking[0].tracking_links[0];

    } catch (err) {
        $("#cover-spin").hide();
        console.log("getEposOrderTrackingDetails", err);
        return err;
    }
};
// order details end

// Field Mapping and upload freshdesk

const getFieldMappingValues = async () => {
    // console.log("Mapping");
    try {
        $("#cover-spin").show();
        const dbData = await client.db.get("fieldmapping")
            .catch((error) => {
                return error;
            });

        if (dbData.status == 404) {
            $("#cover-spin").hide();
            notify("Field mapping should not be empty", "error");
            return;
        }

        let fieldmappings = {};
        Object.values(dbData).forEach((value) => {

            let selectedValue = value.eposContactField;
            let Object = {
                "value": value.freshdeskContactField,
                "dependentValue": value.eposDependentField,
                "default": value.freshdeskContactDefault,
                "dependent": value.hasDependent,

            };
            fieldmappings[selectedValue] = Object;
        });
        return await getContactBodyObject(fieldmappings);
    } catch (err) {
        return err;
    }
};
const getContactBodyObject = async (fieldMappingObjects) => {
    // console.log(fieldMappingObjects,"fieldMappingObjects");
  try {

        let fieldmappingData = Object.keys(fieldMappingObjects);
        let contactBody = {};
        let custom_fields = {};

        fieldmappingData.forEach((data) => {

            if (fieldMappingObjects[data]) {

                let defaultStatus = fieldMappingObjects[data].default;
                let dependentStatus = fieldMappingObjects[data].dependent;
                let dependentValue = fieldMappingObjects[data].dependentValue;
                // let dependentType = Array.isArray(contactDetails[dependentValue]);
                let dependentType = Array.isArray(contactDetails[0][data][dependentValue]);

                let convertedDependentValue = "";
                if (dependentType) {

                    // let dependentFieldValue = contactDetails[dependentValue].toString();
                    let dependentFieldValue = contactDetails[0][data][dependentValue].toString();
                    convertedDependentValue = dependentFieldValue.replaceAll(",", " ");

                } else {
                    convertedDependentValue = contactDetails[0][data][dependentValue];
                    // convertedDependentValue = contactDetails[dependentValue];

                }

                if (defaultStatus == true) {

                    // dependentStatus ? contactBody[fieldMappingObjects[data].value] = convertedDependentValue : contactBody[fieldMappingObjects[data].value] = contactDetails[data];
                    dependentStatus ? contactBody[fieldMappingObjects[data].value] = convertedDependentValue : contactBody[fieldMappingObjects[data].value] = contactDetails[0][data];
                } else {

                    // dependentStatus ? custom_fields[fieldMappingObjects[data].value] = convertedDependentValue : custom_fields[fieldMappingObjects[data].value] = contactDetails[data];
                    dependentStatus ? custom_fields[fieldMappingObjects[data].value] = convertedDependentValue : custom_fields[fieldMappingObjects[data].value] = contactDetails[0][data];
                }
            };
        });
        contactBody["custom_fields"] = custom_fields;
        //  console.log(contactBody,"contactBody");
         await getFreshdeskContact(contactBody);
    } catch (err) {
        $("#cover-spin").hide();d
        console.log("getContactBodyObject->Error->", err);
        notify("Failed Creating Contact1", "error");
        return err;
    }
};
const getFreshdeskContact = async (contactBody) => {

    let requestMethod = "put";
    try {
        const iparams = await loadIparams();
        console.log(freshdeskcontactId,"freshdeskcontactId")
        const url = `https://${iparams.fdDomain}/api/v2/contacts/${freshdeskcontactId}`;
        const headers = {
            Authorization: "Basic " + btoa(iparams.fdApikey),
        }
        await client.request.get(url, { headers });
        return await uploadFreshdeskContact(contactBody, requestMethod);

    } catch (err) {
        if (err.status = "404") {
            requestMethod = "post";
            return await uploadFreshdeskContact(contactBody, requestMethod);
        }
        return err;
    }
};
const uploadFreshdeskContact = async (contactBody, requestMethod) => {
    try {

        let method = requestMethod;
        const iparamsData = await loadIparams();

        requestMethod == "post" ? contactBody : delete contactBody['email'];

        const options = {
            headers: {
                "Content-Type": "application/json",
                Authorization: "Basic " + btoa(iparamsData.fdApikey),
            },
            body: JSON.stringify(contactBody),
        }

        let url = ``;
        if (method == "put") {

            url = `https://${iparamsData.fdDomain}/api/v2/contacts/${freshdeskcontactId}`;
            const updatedResponse = await client.request.put(url, options);
            console.log(updatedResponse,"updatedResponse");
            $("#cover-spin").hide();
            notify("Contact Updated");
            return updatedResponse.response;

        } else {

            url = `https://${iparamsData.fdDomain}/api/v2/contacts`;
            const createdResponse = await client.request.post(url, options);
            $("#cover-spin").hide();
            notify("Contact Created");
            return createdResponse.response;

        }
    } catch (err) {
        $("#cover-spin").hide();
        console.log(err,"contact 2 error")
        notify("Failed Creating Contact2", "error");
        return err;
    }
};

//  upload Freshdesk code_end

//notify
const notify = (message, type = "success") => {
    let bgColor = type == "success" ? `linear-gradient(to right, #00b09b, #96c93d)` : `linear-gradient(to right, #B02E0C, #DC161F)`;
    Toastify({
        text: message,
        duration: 3000,
        newWindow: true,
        close: true,
        gravity: "top",
        style: {
            background: bgColor,
        },
        position: "right",
        stopOnFocus: true
    }).showToast();
};
//notify end

// contactredirect link code
const contactLinkRedirect = async (contactId) => {
    try {
        await getEposContactLinkDetails(contactId);
        window.open(`${contactLink}`, '_blank');
    } catch (err) {
        return err;
    }
};


var contactLink = "";


const getEposContactLinkDetails = (contactId) => {
    try {
        contactLink = `https://epos-web.gke.internal.toolstation.com/#/customer/${contactId}`;
    } catch (err) {
        $("#cover-spin").hide();
        return err;
    }
};
// contactredirect link code end

$(document).on("click", "#backBtn", function () {
    $(`.cardContactsList`).show();
    $(`.indexContactDetails`).hide();
});

$(document).on("click", "#backBtncontact", function () {
    $(`.cardContactsList`).hide();
    $(`.indexContactDetails`).show();
    $(`.contactOrderCards`).hide();
});

$(document).on("click", "#backBtncontactdetails", function () {
    $(`.cardContactsList`).hide();
    $(`.indexContactDetails`).hide();
    $(`.contactOrderCards`).hide();
    $(`.modalContactDetails`).hide();
    $(".uploadContact").hide();
    $('.contactOrderCards').show();
    
});
$(document).on("click", "#backBtnorders", function () {
    $(`.contactOrderCards`).show();
    $(`.cardContactsList`).hide();
    $(`.indexContactDetails`).hide();
    $(`.orderTabs`).hide();
});

const resizeSideBar = (classname) => {

    const elem = document.querySelector(`.${classname}`);
    let rect;
    if (elem) {
        rect = elem.getBoundingClientRect();
    }
    let height = rect.height + 100;

    if (height <= 700) {
        client.instance.resize({ height: `${height}px` });
    } else {
        client.instance.resize({ height: `700px` });
    }

};


const copyUID = async () => {
    try {
        const uid = document.querySelector('#UID');
        let range = document.createRange();
        range.selectNode(uid);
        window.getSelection().addRange(range);
        document.execCommand('copy');
    } catch (err) {
        console.log(err,"err1 in copyUID")
        return err;
    }
    window.getSelection().removeAllRanges();
    try {
        const uid = document.querySelector('#UID');
        let range = document.createRange();
        range.selectNode(uid);
        window.getSelection().addRange(range);
        // let successful = document.execCommand('copy');
        //  successful ? showNotify("success", "UID Copied to Clipboard") : showNotify("danger", "Failed Copying UID");

    } catch (err) {
        console.log(err,"err2 in copyUID");
        return err;
    }
    window.getSelection().removeAllRanges();
};

const showNotify = (type, message) => {


    client.interface.trigger("showNotify", {
        type: type,
        message: message
    });

};