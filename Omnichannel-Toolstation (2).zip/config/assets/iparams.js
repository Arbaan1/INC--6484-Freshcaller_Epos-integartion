var GLOBAL_CONFIG = {
    fieldmapping: {},
    contactConfiguration: {},
    orderConfiguration: {}
}
var disableSelect;
var fdContactFields = []



var existingFreshdeskContactFields = []
var existingEposContactFields = []
var existingEposDependentContactFields = []
var selectedFdContactField = "";
var freshdeskContactFields = {}
var hasDependent = false;

var existingEposOrderFieldsConfiguration = []


const getFreshdeskContactFields = async (authInfo) => {
    try {
        const url = `https://${authInfo.fdDomain}/api/v2/contact_fields`;
        const headers = {
            Authorization: "Basic " + btoa(authInfo.fdApikey)
        };
        return await client.request.get(url, { headers });
    } catch (err) {
        return err;
    }
};

const getEposAccessToken = async (authInfo) => {
    try {
        const url = `https://${authInfo.eposDomain}/oauth2/v1/accesstoken?grant_type=client_credentials`;
        const headers = {
            Authorization: "Basic " + btoa(`${authInfo.eposClientKey}:${authInfo.eposClientSecret}`)
        };
        return await client.request.post(url, { headers });
    } catch (err) {
        console.log("getEposAccessToken->Error->", err)
        return err;
    }
};

const hideExistingFreshdeskContactFields = async () => {
    try {
        existingFreshdeskContactFields = []
        let data = await dbGet("fieldmapping")
            .catch((error) => {
                return error;
            });
        Object.entries(data).forEach(([key, value], index) => {
            if (key) {
                existingFreshdeskContactFields.push(key);
            }
        });
    } catch (err) {
        return err;
    }
};

const hideExistingEposContactFields = async () => {
    try {
        existingEposContactFields = []
        let data = await dbGet("fieldmapping")
            .catch((error) => {
                return error;
            });
        Object.entries(data).forEach(([key, value]) => {
            if (key) {
                existingEposContactFields.push(value.eposContactField);
            }
        });
    } catch (err) {
        return err;
    }
};

const hideExistingEposDependentContactFields = async () => {
    try {
        existingEposDependentContactFields = []
        let data = await dbGet("fieldmapping")
            .catch((error) => {
                return error;
            });
        Object.entries(data).forEach(([key, value]) => {
            if (key) {
                existingEposDependentContactFields.push(value.eposDependentField);
            }
        });
    } catch (err) {
        return err;
    }
};

const appendFreshdeskContactFields = async (contactFields, existingField) => {
    try {
        fdContactFields = contactFields;
        await hideExistingFreshdeskContactFields();

        let selectFreshdeskContactFields = $("#selectFreshdeskContactFields");
        selectFreshdeskContactFields.empty();
        $("#selectFreshdeskContactFields").attr("disabled", disableSelect);

        let fields = ``;
        if (contactFields) {
            fields += `<option value="">-----------None-----------</option>`;
            for (let i = 0; i < contactFields.length; i++) {

                freshdeskContactFields[contactFields[i].name] = contactFields[i]

                let checkField = existingField === contactFields[i].name;
                const conditionCheck = existingFreshdeskContactFields.includes(contactFields[i].name);

                if (conditionCheck == false || checkField == true) {
                    fields += checkField == true ? `<option id="fdContactField" value=${contactFields[i].name} selected>${contactFields[i].label}</option>` : `<option id="fdContactField" value=${contactFields[i].name}>${contactFields[i].label}</option>`;
                }

            }
            selectFreshdeskContactFields.append(fields);
        }
    } catch (err) {
        return err;
    }
};

const appendEposContactFields = async (existingEposField) => {
    try {
        await hideExistingEposContactFields();
        let selectEposContactFields = $("#selectEposContactFields");
        selectEposContactFields.empty();
        let fields = ``;
        fields += `<option value="">-----------None-----------</option>`;
        Object.entries(eposContactFields).forEach(([key, value]) => {

            let checkField = existingEposField === key;
            const conditionCheck = existingEposContactFields.includes(key);

            if (conditionCheck == false || checkField == true) {
                fields += checkField == true ? `<option id="eposContactField" value=${key} selected>${value}</option>` : `<option id="eposContactField" value=${key}>${value}</option>`;
            }

        });
        selectEposContactFields.append(fields);
    } catch (err) {
        return err;
    }
};

$(document).on("change", "#selectEposContactFields", async (e) => {
    const element = $("#selectEposContactFields");
    const value = element.val();
    if (value == "primary_address") {
        hasDependent = true;
        $("#eposDependentContactFields").show();
        await appendDependentEposContactFields();
    } else {
        hasDependent = false;
        $("#eposDependentContactFields").hide();
    }
});

const appendDependentEposContactFields = async (existingField) => {
    try {

        await hideExistingEposDependentContactFields();
        let selectEposDependentContactFields = $("#selectEposDependentContactFields");
        selectEposDependentContactFields.empty();
        let fields = ``;
        fields += `<option value="">-----------None-----------</option>`;
        Object.entries(eposAddressFields).forEach(([key, value]) => {

            let checkField = existingField === key;
            const conditionCheck = existingEposDependentContactFields.includes(key);

            if (conditionCheck == false || checkField == true) {
                fields += checkField == true ? `<option id="eposDependentContactField" value=${key} selected>${value}</option>` : `<option id="eposDependentContactField" value=${key}>${value}</option>`;
            }

        });
        selectEposDependentContactFields.append(fields);
    }
    catch (err) {
        return err;
    }
};

const appendFieldToGlobalVariable = async () => {
    try {
        GLOBAL_CONFIG["fieldmapping"] = await dbGet("fieldmapping");
        if (GLOBAL_CONFIG["fieldmapping"].status == 404) {
            GLOBAL_CONFIG["fieldmapping"] = {}
        }
    } catch (err) {
        return err;
    }
};

const saveFieldmapping = async () => {
    try {
        await appendFieldToGlobalVariable();

        let freshdeskContactField = $("#selectFreshdeskContactFields").val();
        let eposContactField = $("#selectEposContactFields").val();
        let eposDependentContactField = $("#selectEposDependentContactFields").val();

        if ((hasDependent && !eposDependentContactField) || (!freshdeskContactField) || (!eposContactField)) {
            notify("please select valid fields", "error");
            return;
        }

        if ((!freshdeskContactField) && (!eposContactField)) {
            notify("please select valid fields", "error");
            return;
        }

        const freshdeskContactName = freshdeskContactFields[freshdeskContactField].label;
        const freshdeskContactDefault = freshdeskContactFields[freshdeskContactField].default;
        const eposContactName = eposContactFields[eposContactField];
        const eposDependentField = eposDependentContactField;

        let dependentField = ""
        if (hasDependent) {
            dependentField = eposDependentField

        } else {
            dependentField = eposContactField
        }

        const mappingdata = {
            "freshdeskContactField": freshdeskContactField,
            "freshdeskContactName": freshdeskContactName,
            "freshdeskContactDefault": freshdeskContactDefault,
            "eposContactField": eposContactField,
            "eposContactName": eposContactName,
            "hasDependent": hasDependent,
            "eposDependentField": dependentField
        };

        GLOBAL_CONFIG["fieldmapping"][freshdeskContactField] = mappingdata;

        await dbSave("fieldmapping", GLOBAL_CONFIG["fieldmapping"]);
        notify("Fields Saved Successfully");
        await buildFieldsList();

        await appendFreshdeskContactFields(fdContactFields);
        await appendEposContactFields(eposContactFields);
        await appendDependentEposContactFields(eposAddressFields);
        $("#eposDependentContactFields").hide();
        $("#selectFreshdeskContactFields").attr("disabled", false);
        return await appendFieldToGlobalVariable();

    } catch (err) {
        return err;
    }
};

const dbSave = async (dbKey, dbValue) => {
    try {
        return await client.db.set(dbKey, dbValue)
            .catch((error) => {
                return error;
            });
    } catch (err) {
        return err;
    }
};

const dbGet = async (key) => {
    try {
        return await client.db.get(key)
            .catch((error) => {
                return error;
            });
    } catch (err) {
        return err;
    }
};

// //TABLE CREATION FOR SAVE&SHOW FRESHDESK & EPOS CONTACT FIELDS FIELDMAPPING
const buildFieldsList = async () => {
    try {

        GLOBAL_CONFIG["fieldmapping"] = {}

        try {
            let data = await client.db.get("fieldmapping");
            if (data.status != 500) {
                GLOBAL_CONFIG["fieldmapping"] = data
            }
        } catch (err) {

        }

        let fieldmappingList = $("#fieldmappingList");
        fieldmappingList.empty();

        if (Object.keys(GLOBAL_CONFIG["fieldmapping"]).length <= 0) {
            fieldmappingList.html(`<tr> <th colspan="3" style="text-align:center;"> No Data</th></tr>`);
            return;
        }

        let fieldsHtml = `<thead><tr> <th>Freshdesk Contact Field</th> <th>EPOS Contact Field</th> <th>Edit</th> <th>Delete</th> </tr></thead>`;
        for (let key in GLOBAL_CONFIG["fieldmapping"]) {
            let item = GLOBAL_CONFIG["fieldmapping"][key]

            fieldsHtml += `<tr>`;
            fieldsHtml += `<td>${item.freshdeskContactName}</td>`;
            fieldsHtml += `<td>${item.eposContactName}</td>`;
            fieldsHtml += `<td style="justify-content: center; column-gap: 15px; font-size: 1.2em;">
                           <fw-button key="${key}" id="editFieldMapping"><span><i class="fa-solid fa-pen-to-square editFields" style="cursor:pointer" key="${key}" "></i><span/></fw-button>
                           </td> `;
            fieldsHtml += `<td style="justify-content: center; column-gap: 15px; font-size: 1.2em;">
                           <fw-button modal-trigger-id="deleteFieldMappingModal" key="${key}" id="deleteFieldMapping"><span><i class="fas fa-trash deleteFields" style="cursor:pointer" key="${key}" "></i><span/></fw-button>
                           </td> `;
            fieldsHtml += `</tr>`;

        }
        fieldmappingList.html(fieldsHtml);
    } catch (err) {
        return err;
    }
};

$(document).on("click", "#editFieldMapping", async (e) => {
    try {
        disableSelect = true;
        let selectedField = e.target.getAttribute("key")
        await editExistingFields(selectedField);
    } catch (err) {
        return err;
    }
});

const editExistingFields = async (fdField) => {
    try {

        let fieldsData = GLOBAL_CONFIG["fieldmapping"][fdField];
        await appendFreshdeskContactFields(fdContactFields, fieldsData.freshdeskContactField);
        await appendEposContactFields(fieldsData.eposContactField);
        window.scrollTo({ top: 0, behavior: 'smooth' });
        if (fieldsData.eposContactField == "primary_address") {
            await appendDependentEposContactFields(fieldsData.eposDependentField);
            $("#eposDependentContactFields").show();
        } else {
            $("#eposDependentContactFields").hide();
        }
        window.scrollTo({ top: 0, behavior: 'smooth' });

    } catch (err) {
        return err;
    }
};

// FIELD MAPPING TABLE DELETE BUTTON
$(document).on("click", "#deleteFieldMapping", e => {
    try {
        selectedFdContactField = "";
        let fdContactField = e.target.getAttribute("key");
        selectedFdContactField = fdContactField;
    } catch (err) {
        return err;
    }
});

const modalNoFieldMapping = () => {
    document.getElementById('deleteFieldMappingModal').visible = false;
};

const modalYesFieldMapping = async () => {
    try {

        if (GLOBAL_CONFIG["fieldmapping"] != undefined) {
            delete GLOBAL_CONFIG["fieldmapping"][selectedFdContactField]
        }
        let storedData = GLOBAL_CONFIG["fieldmapping"]
        return await saveUpdatedData(storedData);

    } catch (err) {
        return err;
    }
};

const saveUpdatedData = async (storedData) => {
    try {
        let savedData = "";
        if (Object.keys(storedData).length == 0) {
            savedData = await client.db.delete("fieldmapping")
                .catch((error) => {
                    return error;
                });
            notify("Fields Deleted Successfully", "error");
            document.getElementById('deleteFieldMappingModal').visible = false;
            await appendFieldToGlobalVariable();
            await appendFreshdeskContactFields(fdContactFields);
            await appendEposContactFields(eposContactFields);
            await appendDependentEposContactFields(eposAddressFields);
            $("#eposDependentContactFields").hide();
            $("#selectFreshdeskContactFields").attr("disabled", false);
            return await buildFieldsList();
        } else {
            savedData = await dbSave("fieldmapping", storedData)
                .catch((error) => {
                    return error;
                });
            notify("Fields Deleted Successfully", "error");
            document.getElementById('deleteFieldMappingModal').visible = false;
            await appendFieldToGlobalVariable();
            await appendFreshdeskContactFields(fdContactFields);
            await appendEposContactFields(eposContactFields);
            await appendDependentEposContactFields(eposAddressFields);
            $("#eposDependentContactFields").hide();
            $("#selectFreshdeskContactFields").attr("disabled", false);
            return await buildFieldsList();
        }
    } catch (err) {
        return err;
    }
};


const switchTab = (position) => {
    $("#tabs").attr("active-tab-index", position);
};

const notify = (message, type = "success") => {
    let bgColor = type == "success" ? `linear-gradient(to right, #00b09b, #96c93d)` : `linear-gradient(to right, #B02E0C, #DC161F)`;
    Toastify({
        text: message,
        duration: 3000,
        newWindow: true,
        close: true,
        gravity: "top",
        style: {
            background: bgColor,
            borderLeft: `1px solid ${bgColor}`
        },
        position: "right",
        stopOnFocus: true
    }).showToast();
};

const handleError = (err) => {
    if ($('#domain').val() == '' && $("#apikey").val() == '') {
        notify("Please Enter Domain & ApiKey", "error");
        return;
    }
    if (err.status == 400) {
        notify("Invalid Freshdesk Domain", "error");
        return;
    }
    if (err.status == 403) {
        notify("Invalid Freshdesk API Key", "error");
        return;
    }
    if (err.status == 502) {
        notify("Bad Gateway server error", "error");
        return;
    }
    if (err.status == 401) {
        notify("Login Failed. Invalid or Expired API", "error");
        return;
    }
    else {
        notify("Invalid Freshdesk Credentials", "error");
        return;
    }
};


// TAB 5 
const appendOrderFieldsConfiguration = async (existingOrderField) => {
    try {

        await hideExistingEposOrderFieldsConfiguration();
        let selectEposOrderConfiguration = $("#selectEposOrderConfiguration");
        selectEposOrderConfiguration.empty();
        let fields = ``;
        fields += `<option value="">-----------None-----------</option>`;
        Object.entries(eposOrderFields).forEach(([key, value]) => {

            let checkField = existingOrderField === key;
            const conditionCheck = existingEposOrderFieldsConfiguration.includes(key);

            if (conditionCheck == false || checkField == true) {

                fields += checkField == true ? `<option id="eposOrderField" value=${key} selected>${value}</option>` : `<option id="eposOrderField" value=${key}>${value}</option>`;

            }

        });
        selectEposOrderConfiguration.append(fields);
    } catch (err) {
        console.log("appendOrderFieldsConfiguration->Error->", err);
        return err;
    }
};


const hideExistingEposOrderFieldsConfiguration = async () => {
    try {

        existingEposOrderFieldsConfiguration = []
        let data = await dbGet("orderConfiguration")
            .catch((error) => {
                return error;
            });
        Object.entries(data).forEach(([key, value]) => {
            if (key) {
                existingEposOrderFieldsConfiguration.push(value.eposOrderField);
            }
        });
    } catch (err) {
        console.log("hideExistingEposOrderFieldsConfiguration->Error->", err);
        return err;
    }
};


const appendOrderFieldsToGlobalVariable = async () => {
    try {

        GLOBAL_CONFIG["orderConfiguration"] = await dbGet("orderConfiguration");
        if (GLOBAL_CONFIG["orderConfiguration"].status == 404) {
            GLOBAL_CONFIG["orderConfiguration"] = {}
        }
    } catch (err) {
        console.log("appendOrderFieldsToGlobalVariable->Error->", err);
        return err;
    }
};


const saveOrderConfiguration = async () => {
    try {

        await appendOrderFieldsToGlobalVariable();

        let eposOrderField = $("#selectEposOrderConfiguration").val();

        if (!eposOrderField) {
            notify("please select valid fields", "error");
            return;
        }

        const eposOrderName = eposOrderFields[eposOrderField];

        const orderFieldsData = {
            "eposOrderField": eposOrderField,
            "eposOrderName": eposOrderName
        };

        GLOBAL_CONFIG["orderConfiguration"][eposOrderField] = orderFieldsData;

        await dbSave("orderConfiguration", GLOBAL_CONFIG["orderConfiguration"]);
        notify("Field Saved Successfully");

        await buildOrderFieldsList();
        await appendOrderFieldsConfiguration();
        return await appendOrderFieldsToGlobalVariable();

    } catch (err) {
        console.log("saveOrderConfiguration->Error->", err);
        return err;
    }
};


const buildOrderFieldsList = async () => {
    try {

        GLOBAL_CONFIG["orderConfiguration"] = {}

        try {
            let data = await client.db.get("orderConfiguration");
            if (data.status != 500) {
                GLOBAL_CONFIG["orderConfiguration"] = data
            }
        } catch (err) {

        }

        let orderFieldsList = $("#orderFieldsList");
        orderFieldsList.empty();

        if (Object.keys(GLOBAL_CONFIG["orderConfiguration"]).length <= 0) {
            orderFieldsList.html(`<tr> <th colspan="3" style="text-align:center;"> No Data</th></tr>`);
            return;
        }

        let orderFieldsHtml = `<thead> <tr> <th>EPOS Order Fields</th> <th>Delete</th> </tr> </thead>`;
        for (let key in GLOBAL_CONFIG["orderConfiguration"]) {
            let item = GLOBAL_CONFIG["orderConfiguration"][key]

            orderFieldsHtml += `<tr>`;
            orderFieldsHtml += `<td>${item.eposOrderName}</td>`;
            orderFieldsHtml += `<td style="justify-content: center; column-gap: 15px; font-size: 1.2em;">
                           <fw-button modal-trigger-id="deleteOrderFieldsModal" key="${key}" id="deleteOrderConfiguration"><span><i class="fas fa-trash deleteFields" style="cursor:pointer" key="${key}" "></i><span/></fw-button>
                           </td> `;
            orderFieldsHtml += `</tr>`;

        }
        orderFieldsList.html(orderFieldsHtml);
    } catch (err) {
        console.log("buildOrderFieldsList->Error->", err);
        return err;
    }
};


var selectedEposOrderField = "";

$(document).on("click", "#deleteOrderConfiguration", e => {
    try {
        selectedEposOrderField = "";
        let orderField = e.target.getAttribute("key");
        selectedEposOrderField = orderField;
    } catch (err) {
        console.log("deleteOrderConfiguration->Error->", err);
        return err;
    }
});

const modalNoOrderFieldsConfiguration = () => {
    document.getElementById('deleteOrderFieldsModal').visible = false;
};

const modalYesOrderFieldsConfiguration = async () => {
    try {

        if (GLOBAL_CONFIG["orderConfiguration"] != undefined) {
            delete GLOBAL_CONFIG["orderConfiguration"][selectedEposOrderField]
        }
        let storedData = GLOBAL_CONFIG["orderConfiguration"]
        return await saveUpdatedOrderFieldsData(storedData);

    } catch (err) {
        return err;
    }
};

const saveUpdatedOrderFieldsData = async (storedData) => {
    try {
        let savedData = "";
        if (Object.keys(storedData).length == 0) {
            savedData = await client.db.delete("orderConfiguration")
                .catch((error) => {
                    return error;
                });
            notify("Fields Deleted Successfully", "error");
            document.getElementById('deleteOrderFieldsModal').visible = false;
            await appendOrderFieldsToGlobalVariable();
            await appendOrderFieldsConfiguration();
            return await buildOrderFieldsList();
        } else {
            savedData = await dbSave("orderConfiguration", storedData)
                .catch((error) => {
                    return error;
                });
            notify("Fields Deleted Successfully", "error");
            document.getElementById('deleteOrderFieldsModal').visible = false;
            await appendOrderFieldsToGlobalVariable();
            await appendOrderFieldsConfiguration();
            return await buildOrderFieldsList();
        }
    } catch (err) {
        console.log("saveUpdatedOrderFieldsData->Error->", err);
        return err;
    }
};


// TAB 4

var disableContactFieldsConfiguration;
var existingEposContactFieldsConfiguration = [];

const appendContactFieldsConfiguration = async (existingContactField) => {
    try {
        await hideExistingEposContactFieldsConfiguration();

        $("#selectEposContactConfiguration").attr("disabled", disableContactFieldsConfiguration);

        let selectEposContactConfiguration = $("#selectEposContactConfiguration");
        selectEposContactConfiguration.empty();
        let fields = ``;
        fields += `<option value="">-----------None-----------</option>`;
        Object.entries(eposContactFields).forEach(([key, value]) => {

            let checkField = existingContactField === key;
            const conditionCheck = existingEposContactFieldsConfiguration.includes(key);

            if (conditionCheck == false || checkField == true) {

                fields += checkField == true ? `<option id="eposcontactFields" value=${key} selected>${value}</option>` : `<option id="eposOrderField" value=${key}>${value}</option>`;

            }

        });
        selectEposContactConfiguration.append(fields);
    } catch (err) {
        console.log("appendContactFieldsConfiguration->Error->", err);
        return err;
    }
};


const hideExistingEposContactFieldsConfiguration = async () => {
    try {

        existingEposContactFieldsConfiguration = []
        let data = await dbGet("contactConfiguration")
            .catch((error) => {
                return error;
            });
        Object.entries(data).forEach(([key, value]) => {
            if (key) {
                existingEposContactFieldsConfiguration.push(value.eposContactField);
            }
        });
    } catch (err) {
        console.log("hideExistingEposContactFieldsConfiguration->Error->", err);
        return err;
    }
};


const appendContactFieldsToGlobalVariable = async () => {
    try {

        GLOBAL_CONFIG["contactConfiguration"] = await dbGet("contactConfiguration");
        if (GLOBAL_CONFIG["contactConfiguration"].status == 404) {
            GLOBAL_CONFIG["contactConfiguration"] = {}
        }
    } catch (err) {
        console.log("appendOrderFieldsToGlobalVariable->Error->", err);
        return err;
    }
};


const saveContactConfiguration = async () => {
    try {

        await appendContactFieldsToGlobalVariable();

        let eposContactField = $("#selectEposContactConfiguration").val();

        const isIndex = document.getElementById("chkbxIndex").checked;
        const isModal = document.getElementById("chkbxModal").checked;

        if (!eposContactField) {
            notify("please select valid fields", "error");
            return;
        }
        else if (!isIndex && !isModal) {
            notify("please select Index or Modal", "error");
            return;
        }

        const eposContactName = eposContactFields[eposContactField];

        let selectedToShowIn = "";

        if (isIndex && isModal) {
            selectedToShowIn = "Index & Modal";
        } else if (isIndex) {
            selectedToShowIn = "Index";
        } else if (isModal) {
            selectedToShowIn = "Modal";
        }

        const contactFieldsData = {
            "eposContactField": eposContactField,
            "eposContactName": eposContactName,
            "isIndex": isIndex,
            "isModal": isModal,
            "selectedToShowIn": selectedToShowIn
        };

        GLOBAL_CONFIG["contactConfiguration"][eposContactField] = contactFieldsData;

        await dbSave("contactConfiguration", GLOBAL_CONFIG["contactConfiguration"]);
        notify("Field Saved Successfully");

        document.getElementById("chkbxIndex").checked = false
        document.getElementById("chkbxModal").checked = false
        document.getElementById("chkbxIndex").disabled = false;
        disableContactFieldsConfiguration = false;

        await buildContactFieldsList();
        await appendContactFieldsConfiguration();
        return await appendContactFieldsToGlobalVariable();

    } catch (err) {
        console.log("saveOrderConfiguration->Error->", err);
        return err;
    }
};


const buildContactFieldsList = async () => {
    try {

        GLOBAL_CONFIG["contactConfiguration"] = {}

        try {
            let data = await client.db.get("contactConfiguration");
            if (data.status != 500) {
                GLOBAL_CONFIG["contactConfiguration"] = data
            }
        } catch (err) {

        }

        let contactFieldsList = $("#contactFieldsList");
        contactFieldsList.empty();

        if (Object.keys(GLOBAL_CONFIG["contactConfiguration"]).length <= 0) {
            contactFieldsList.html(`<tr> <th colspan="3" style="text-align:center;"> No Data</th></tr>`);
            return;
        }

        let contactFieldsHtml = `<thead> <tr> <th>EPOS Contact Fields</th> <th>Selected Option</th> <th>Edit</th> <th>Delete</th> </tr> </thead>`;
        for (let key in GLOBAL_CONFIG["contactConfiguration"]) {
            let item = GLOBAL_CONFIG["contactConfiguration"][key]

            contactFieldsHtml += `<tr>`;
            contactFieldsHtml += `<td>${item.eposContactName}</td>`;
            contactFieldsHtml += `<td>${item.selectedToShowIn}</td>`;
            contactFieldsHtml += `<td style="justify-content: center; column-gap: 15px; font-size: 1.2em;">
            <fw-button key="${key}" id="editContactConfiguration"><span><i class="fa-solid fa-pen-to-square editFields" style="cursor:pointer" key="${key}" "></i><span/></fw-button>
            </td> `;
            contactFieldsHtml += `<td style="justify-content: center; column-gap: 15px; font-size: 1.2em;">
                           <fw-button modal-trigger-id="deleteContactFieldsModal" key="${key}" id="deleteContactConfiguration"><span><i class="fas fa-trash deleteFields" style="cursor:pointer" key="${key}" "></i><span/></fw-button>
                           </td> `;
            contactFieldsHtml += `</tr>`;

        }
        contactFieldsList.html(contactFieldsHtml);
    } catch (err) {
        console.log("buildContactFieldsList->Error->", err);
        return err;
    }
};


$(document).on("click", "#editContactConfiguration", async (e) => {
    try {
        disableContactFieldsConfiguration = true;
        let selectedField = e.target.getAttribute("key")
        await editExistingEposContactFields(selectedField);
    } catch (err) {
        return err;
    }
});

const editExistingEposContactFields = async (contactField) => {
    try {

        let fieldsData = GLOBAL_CONFIG["contactConfiguration"][contactField];
        await appendContactFieldsConfiguration(fieldsData.eposContactField);
        document.getElementById("chkbxIndex").checked = fieldsData.isIndex;
        document.getElementById("chkbxModal").checked = fieldsData.isModal;

        let selectedField = $("#selectEposContactConfiguration").val();

        if (selectedField == "primary_address") {

            document.getElementById("chkbxIndex").disabled = true;

        } else {

            document.getElementById("chkbxIndex").disabled = false;

        }

        window.scrollTo({ top: 0, behavior: 'smooth' });

    } catch (err) {
        return err;
    }
};


var selectedEposContactField = "";

$(document).on("click", "#deleteContactConfiguration", e => {
    try {
        selectedEposContactField = "";
        let contactField = e.target.getAttribute("key");
        selectedEposContactField = contactField;
    } catch (err) {
        console.log("deleteContactConfiguration->Error->", err);
        return err;
    }
});


const modalNoContactFieldsConfiguration = () => {
    document.getElementById('deleteContactFieldsModal').visible = false;
};


const modalYesContactFieldsConfiguration = async () => {
    try {

        if (GLOBAL_CONFIG["contactConfiguration"] != undefined) {
            delete GLOBAL_CONFIG["contactConfiguration"][selectedEposContactField]
        }
        let storedData = GLOBAL_CONFIG["contactConfiguration"]
        return await saveUpdatedContactFieldsData(storedData);

    } catch (err) {
        return err;
    }
};


const saveUpdatedContactFieldsData = async (storedData) => {
    try {
        let savedData = "";
        if (Object.keys(storedData).length == 0) {
            savedData = await client.db.delete("contactConfiguration")
                .catch((error) => {
                    return error;
                });
            notify("Fields Deleted Successfully", "error");
            document.getElementById('deleteContactFieldsModal').visible = false;
            await appendContactFieldsToGlobalVariable();
            await appendContactFieldsConfiguration();
            return await buildContactFieldsList();
        } else {
            savedData = await dbSave("contactConfiguration", storedData)
                .catch((error) => {
                    return error;
                });
            notify("Fields Deleted Successfully", "error");
            document.getElementById('deleteContactFieldsModal').visible = false;

            document.getElementById("chkbxIndex").checked = false
            document.getElementById("chkbxModal").checked = false
            document.getElementById("chkbxIndex").disabled = false;
            disableContactFieldsConfiguration = false;
            await appendContactFieldsToGlobalVariable();
            await appendContactFieldsConfiguration();
            return await buildContactFieldsList();
        }
    } catch (err) {
        console.log("saveUpdatedContactFieldsData->Error->", err);
        return err;
    }
};


$(document).on("change", "#selectEposContactConfiguration", (e) => {

    let selectedField = $("#selectEposContactConfiguration").val();

    if (selectedField == "primary_address") {

        document.getElementById("chkbxIndex").disabled = true;

    } else {

        document.getElementById("chkbxIndex").disabled = false;

    }

});